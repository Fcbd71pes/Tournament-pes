# config.py

# --- Telegram Bot Configuration ---
BOT_TOKEN = "6356360750:AAE7MpI223usUbTheLo1f6ccLK8zRrOMI1Q"
ADMIN_IDS = [5172723202]  # Add more admin IDs separated by commas
CHANNEL_ID = -1002439749625 # Your public channel ID

# --- Database Configuration ---
DB_NAME = "hagu_bot_pro_v5.db"

# --- Bot Settings ---
DEPOSIT_INFO = """
💰 **ডিপোজিট করার নিয়ম** 💰

আপনার বিকাশ/নগদ নম্বর 01914573762
"""
ENTRY_FEES = [10, 20, 50, 100]
PRIZE_CUT_PERCENTAGE = 10
MATCH_DURATION_MINUTES = 12

# --- Referral System Settings ---
REFERRAL_ENABLED = True
REFERRAL_COMMISSION_TK = 5.0
MIN_DEPOSIT_FOR_REFERRAL = 50.0

# --- Conversation Handler States ---
# These are used to manage multi-step interactions with the user
(
    GET_IGN,
    GET_EMAIL,
    GET_PHONE,
    DISPUTE_SCREENSHOT,
) = range(4)