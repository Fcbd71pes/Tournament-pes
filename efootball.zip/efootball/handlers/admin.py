# handlers/admin.py
import logging
from telegram import Update
from telegram.ext import ContextTypes
from database import execute_query
from config import ADMIN_IDS, REFERRAL_ENABLED, MIN_DEPOSIT_FOR_REFERRAL, REFERRAL_COMMISSION_TK

logger = logging.getLogger(__name__)

async def add_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id not in ADMIN_IDS:
        return

    try:
        target_user_id = int(context.args[0])
        amount = float(context.args[1])

        execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, target_user_id))
        await update.message.reply_text(f"✅ `{target_user_id}`-এর অ্যাকাউন্টে `{amount:.2f} TK` যোগ করা হয়েছে।")
        await context.bot.send_message(target_user_id, f"🎉 আপনার অ্যাকাউন্টে `{amount:.2f} TK` যোগ করা হয়েছে।")

        # Handle referral commission
        if REFERRAL_ENABLED and amount >= MIN_DEPOSIT_FOR_REFERRAL:
            user_data = execute_query("SELECT referred_by, first_deposit_done FROM users WHERE user_id = ?", (target_user_id,), fetch='one')
            if user_data and not user_data[1]: # If not first deposit done
                referrer_id = user_data[0]
                if referrer_id:
                    execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (REFERRAL_COMMISSION_TK, referrer_id))
                    await context.bot.send_message(referrer_id, f"🎉 অভিনন্দন! আপনার রেফার করা বন্ধু প্রথম ডিপোজিট করেছে। আপনি {REFERRAL_COMMISSION_TK} TK বোনাস পেয়েছেন।")
                execute_query("UPDATE users SET first_deposit_done = 1 WHERE user_id = ?", (target_user_id,))

    except (IndexError, ValueError):
        await update.message.reply_text("⚠️ ভুল ফরম্যাট। ব্যবহার করুন: `/add_balance <user_id> <amount>`")
    except Exception as e:
        logger.error(f"Error in add_balance: {e}")
        await update.message.reply_text("ব্যালেন্স যোগ করার সময় একটি ত্রুটি হয়েছে।")