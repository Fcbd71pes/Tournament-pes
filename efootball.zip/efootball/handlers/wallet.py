# handlers/wallet.py
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.helpers import escape_markdown
from database import execute_query
from config import DEPOSIT_INFO, REFERRAL_ENABLED, MIN_DEPOSIT_FOR_REFERRAL, REFERRAL_COMMISSION_TK

async def my_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    balance = execute_query("SELECT balance FROM users WHERE user_id = ?", (user_id,), fetch='one')[0]
    
    keyboard = [
        [InlineKeyboardButton("➕ Deposit", callback_data='deposit')],
        [InlineKeyboardButton("➖ Withdraw", callback_data='withdraw')]
    ]
    if REFERRAL_ENABLED:
        keyboard.append([InlineKeyboardButton("🤝 My Referrals", callback_data='my_referrals')])
        
    await query.edit_message_text(f"💳 **My Wallet**\n\n**বর্তমান ব্যালেন্স:** `{balance:.2f} TK`", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def deposit_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.message.reply_text(DEPOSIT_INFO, parse_mode='Markdown')

async def withdraw_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.message.reply_text("কত টাকা উইথড্র করতে চান এবং আপনার নম্বরটি পাঠান।")

async def my_referrals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    ref_link = f"https://t.me/{context.bot.username}?start={user_id}"
    ref_count = execute_query("SELECT COUNT(*) FROM users WHERE referred_by = ?", (user_id,), fetch='one')[0]
    
    message = (
        f"🤝 **আপনার রেফারেল**\n\n"
        f"আপনার ইউনিক রেফারেল লিঙ্ক:\n`{escape_markdown(ref_link, version=2)}`\n\n"
        f"এই লিঙ্কটি বন্ধুদের সাথে শেয়ার করুন। যখন আপনার বন্ধু এই লিঙ্ক ব্যবহার করে যোগ দেবে এবং প্রথমবার কমপক্ষে `{MIN_DEPOSIT_FOR_REFERRAL}` টাকা ডিপোজিট করবে, আপনি `{REFERRAL_COMMISSION_TK}` টাকা বোনাস পাবেন!\n\n"
        f"*আপনার মোট সফল রেফারেল:* `{ref_count}` জন"
    )
    await query.edit_message_text(message, parse_mode='MarkdownV2')