# handlers/registration.py
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from database import execute_query
from config import GET_IGN, GET_EMAIL, GET_PHONE
from .matchmaking import show_main_menu # Import from another handler file

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    execute_query("INSERT OR IGNORE INTO users (user_id, username, is_registered) VALUES (?, ?, 0)", (user.id, user.username or user.first_name))

    if context.args:
        try:
            referrer_id = int(context.args[0])
            if referrer_id != user.id:
                execute_query("UPDATE users SET referred_by = ? WHERE user_id = ? AND referred_by IS NULL", (referrer_id, user.id))
        except (ValueError, IndexError):
            pass  # Ignore invalid referral codes

    is_registered = execute_query("SELECT is_registered FROM users WHERE user_id = ?", (user.id,), fetch='one')[0]
    if is_registered:
        await show_main_menu(update, context, f"👋 আবার স্বাগতম, {user.first_name}!")
        return ConversationHandler.END
    else:
        await update.message.reply_text("👋 স্বাগতম! রেজিস্ট্রেশন করতে আপনার **eFootball ইন-গেম নাম (IGN)** পাঠান।\n\n⚠️ **সতর্কতা:** এই নামটি পরিবর্তন করা যাবে না।", parse_mode='Markdown')
        return GET_IGN

async def get_ign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user, ign = update.effective_user, update.message.text
    execute_query("UPDATE users SET ingame_name = ? WHERE user_id = ?", (ign, user.id))
    keyboard = [[InlineKeyboardButton("⏭️ Skip", callback_data='skip_email')]]
    await update.message.reply_text(f"✅ IGN সেট করা হয়েছে: `{ign}`\n\nএখন আপনার ইমেইল দিন। (ঐচ্ছিক)", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    return GET_EMAIL

async def get_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    execute_query("UPDATE users SET email = ? WHERE user_id = ?", (update.message.text, update.effective_user.id))
    await update.message.reply_text("✅ ইমেইল সেভ করা হয়েছে।\n\nসবশেষে, আপনার মোবাইল নম্বর দিন।")
    return GET_PHONE

async def skip_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("✅ ইমেইল ধাপটি Skip করা হয়েছে।\n\nসবশেষে, আপনার মোবাইল নম্বর দিন।")
    return GET_PHONE

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    execute_query("UPDATE users SET phone_number = ? WHERE user_id = ?", (update.message.text, user_id))
    execute_query("UPDATE users SET is_registered = 1 WHERE user_id = ?", (user_id,))
    await update.message.reply_text("🎉 অভিনন্দন! আপনার রেজিস্ট্রেশন সম্পন্ন হয়েছে।")
    await show_main_menu(update, context, "এখন আপনি নিচের অপশনগুলো থেকে বেছে নিতে পারেন:")
    return ConversationHandler.END

async def cancel_registration(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("রেজিস্ট্রেশন বাতিল করা হয়েছে। আবার শুরু করতে /start লিখুন।")
    return ConversationHandler.END