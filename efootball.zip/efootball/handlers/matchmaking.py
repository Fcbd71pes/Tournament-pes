# handlers/matchmaking.py
import logging
import random
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler
from telegram.helpers import escape_markdown
from telegram.error import TelegramError

from database import execute_query
from config import ADMIN_IDS, CHANNEL_ID, ENTRY_FEES, PRIZE_CUT_PERCENTAGE, MATCH_DURATION_MINUTES, DISPUTE_SCREENSHOT

logger = logging.getLogger(__name__)
dispute_screenshots = {}

# --- Helper Functions ---
async def safe_send_message(context: ContextTypes.DEFAULT_TYPE, chat_id: int, text: str, **kwargs):
    try:
        await context.bot.send_message(chat_id=chat_id, text=text, **kwargs)
        return True
    except TelegramError as e:
        logger.error(f"Failed to send message to {chat_id}: {e}")
        return False

# --- Main Menu (called from other modules) ---
async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, message: str):
    user_id = update.effective_user.id
    keyboard = [
        [InlineKeyboardButton("🎮 Play 1v1 Match", callback_data='play_1v1')],
        [InlineKeyboardButton("💰 My Wallet", callback_data='my_wallet')],
        [InlineKeyboardButton("🏆 Tournaments", callback_data='tournaments')]
    ]
    if update.callback_query:
        await update.callback_query.message.reply_text(message, reply_markup=InlineKeyboardMarkup(keyboard))
    else:
        await safe_send_message(context, user_id, message, reply_markup=InlineKeyboardMarkup(keyboard))

# --- Matchmaking Flow ---
async def play_1v1(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    keyboard = [[InlineKeyboardButton(f"{fee} TK", callback_data=f"fee_{fee}")] for fee in ENTRY_FEES]
    await query.edit_message_text("আপনার পছন্দের এন্ট্রি ফি নির্বাচন করুন:", reply_markup=InlineKeyboardMarkup(keyboard))

async def fee_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    fee = float(query.data.split('_')[1])

    # Check if user is already in queue or in a match
    if execute_query("SELECT 1 FROM matchmaking_queue WHERE user_id = ?", (user_id,), fetch='one'):
        await query.answer("আপনি ইতিমধ্যে একটি ম্যাচ খুঁজছেন।", show_alert=True)
        return
    if execute_query("SELECT 1 FROM active_matches WHERE (player1_id = ? OR player2_id = ?) AND status NOT LIKE 'completed%'", (user_id, user_id), fetch='one'):
        await query.answer("আপনার ইতিমধ্যে একটি ম্যাচ চলমান আছে।", show_alert=True)
        return

    balance = execute_query("SELECT balance FROM users WHERE user_id = ?", (user_id,), fetch='one')[0]
    if balance < fee:
        await query.answer("❌ আপনার অ্যাকাউন্টে পর্যাপ্ত ব্যালেন্স নেই!", show_alert=True)
        return

    await query.edit_message_text(f"{fee:.0f} TK-এর জন্য ম্যাচ খোঁজা হচ্ছে...", reply_markup=None)
    
    opponent_id_tuple = execute_query("SELECT user_id FROM matchmaking_queue WHERE fee = ? AND user_id != ? ORDER BY timestamp ASC LIMIT 1", (fee, user_id), fetch='one')
    
    if opponent_id_tuple:
        opponent_id = opponent_id_tuple[0]
        execute_query("DELETE FROM matchmaking_queue WHERE user_id IN (?, ?)", (opponent_id, user_id))
        await match_found(context, opponent_id, user_id, fee)
    else:
        execute_query("INSERT OR REPLACE INTO matchmaking_queue (user_id, fee, timestamp) VALUES (?, ?, ?)", (user_id, fee, int(time.time())))
        await context.bot.send_message(CHANNEL_ID, f"🔥 একটি নতুন চ্যালেঞ্জ!\n**ফি:** {fee:.0f} TK\nখেলতে চাইলে বটে আসুন: @{context.bot.username}")

async def match_found(context: ContextTypes.DEFAULT_TYPE, player1_id: int, player2_id: int, fee: float):
    match_id = f"m_{int(time.time())}_{random.randint(100, 999)}"
    
    # Deduct balance from both players
    execute_query("UPDATE users SET balance = balance - ? WHERE user_id = ?", (fee, player1_id))
    execute_query("UPDATE users SET balance = balance - ? WHERE user_id = ?", (fee, player2_id))
    
    # Create match in DB
    execute_query("INSERT INTO active_matches (match_id, player1_id, player2_id, fee, status) VALUES (?, ?, ?, ?, ?)", (match_id, player1_id, player2_id, fee, 'waiting_for_code'))
    
    await safe_send_message(context, player1_id, f"🎉 ম্যাচ পাওয়া গেছে! আপনার প্রতিপক্ষ ID: {player2_id}।\n\n**অনুগ্রহ করে eFootball-এ একটি ৮ মিনিটের, পাসওয়ার্ড ছাড়া রুম তৈরি করে রুম কোডটি এখানে পাঠান**।")
    await safe_send_message(context, player2_id, f"🎉 ম্যাচ পাওয়া গেছে! আপনার প্রতিপক্ষ ID: {player1_id}।\n\nআপনার প্রতিপক্ষ রুম কোড পাঠালে আপনাকে জানানো হবে।")

# --- Result and Dispute Flow ---
async def trigger_ask_for_result(context: ContextTypes.DEFAULT_TYPE):
    await ask_for_result_logic(context, context.job.data['match_id'])

async def ask_for_result_logic(context: ContextTypes.DEFAULT_TYPE, match_id: str):
    match_data = execute_query("SELECT * FROM active_matches WHERE match_id = ?", (match_id,), fetch='one')
    if not match_data or match_data[4] != 'in_progress':
        return

    player1_id, player2_id = match_data[1], match_data[2]
    keyboard = [[InlineKeyboardButton("✅ আমি জিতেছি", callback_data=f"result_won_{match_id}")], [InlineKeyboardButton("❌ আমি হেরেছি", callback_data=f"result_lost_{match_id}")]]
    reply_markup = InlineKeyboardMarkup(keyboard)

    p1_sent = await safe_send_message(context, player1_id, "খেলা কেমন হলো? অনুগ্রহ করে ফলাফল জানান।", reply_markup=reply_markup)
    p2_sent = await safe_send_message(context, player2_id, "খেলা কেমন হলো? অনুগ্রহ করে ফলাফল জানান।", reply_markup=reply_markup)
    
    if p1_sent or p2_sent:
        execute_query("UPDATE active_matches SET status = ? WHERE match_id = ?", ('waiting_for_result', match_id))

async def process_match_end(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    _, result, match_id = query.data.split('_')

    match_data = execute_query("SELECT * FROM active_matches WHERE match_id = ?", (match_id,), fetch='one')
    if not match_data:
        await query.edit_message_text("এই ম্যাচটি আর সক্রিয় নেই।")
        return

    player1_id, player2_id, fee, status, p1_res, p2_res = match_data[1], match_data[2], match_data[3], match_data[4], match_data[5], match_data[6]

    if user_id == player1_id: p1_res = result
    elif user_id == player2_id: p2_res = result
    else: return

    execute_query(f"UPDATE active_matches SET p{1 if user_id == player1_id else 2}_result = ? WHERE match_id = ?", (result, match_id))
    await query.edit_message_text("ফলাফল রেকর্ড করা হয়েছে। আপনার প্রতিপক্ষের ফলাফলের জন্য অপেক্ষা করা হচ্ছে...")

    if p1_res and p2_res:
        if (p1_res, p2_res) in [('won', 'lost'), ('lost', 'won')]:
            winner, loser = (player1_id, player2_id) if p1_res == 'won' else (player2_id, player1_id)
            prize = (fee * 2) * (1 - PRIZE_CUT_PERCENTAGE / 100)
            execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (prize, winner))
            await safe_send_message(context, winner, f"🏆 অভিনন্দন! আপনি ম্যাচ জিতেছেন এবং `{prize:.2f} TK` পুরস্কার পেয়েছেন।")
            await safe_send_message(context, loser, "😔 দুঃখিত, আপনি হেরেছেন।")
            execute_query("DELETE FROM active_matches WHERE match_id = ?", (match_id,))
        elif p1_res == 'won' and p2_res == 'won':
            execute_query("UPDATE active_matches SET status = ? WHERE match_id = ?", ('disputed_pending_screenshots', match_id))
            dispute_screenshots[match_id] = {'p1_id': player1_id, 'p2_id': player2_id, 'p1_ss': None, 'p2_ss': None}
            await safe_send_message(context, player1_id, "⚠️ ফলাফলে বিরোধ। অনুগ্রহ করে আপনার জয়ের একটি স্পষ্ট স্ক্রিনশট **এই চ্যাটে আপলোড করুন**।")
            await safe_send_message(context, player2_id, "⚠️ ফলাফলে বিরোধ। অনুগ্রহ করে আপনার জয়ের একটি স্পষ্ট স্ক্রিনশট **এই চ্যাটে আপলোড করুন**।")
            return DISPUTE_SCREENSHOT
    return ConversationHandler.END

async def screenshot_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    match_id_tuple = execute_query("SELECT match_id FROM active_matches WHERE (player1_id = ? OR player2_id = ?) AND status = ?", (user_id, user_id, 'disputed_pending_screenshots'), fetch='one')
    if not match_id_tuple:
        return ConversationHandler.END
    match_id = match_id_tuple[0]

    if match_id not in dispute_screenshots:
        return ConversationHandler.END # Should not happen

    photo_id = update.message.photo[-1].file_id
    if user_id == dispute_screenshots[match_id]['p1_id']:
        dispute_screenshots[match_id]['p1_ss'] = photo_id
    else:
        dispute_screenshots[match_id]['p2_ss'] = photo_id

    await safe_send_message(context, user_id, "✅ আপনার স্ক্রিনশট গ্রহণ করা হয়েছে।")

    if all(dispute_screenshots[match_id].values()):
        p1_id = dispute_screenshots[match_id]['p1_id']
        p2_id = dispute_screenshots[match_id]['p2_id']
        p1_details = execute_query("SELECT ingame_name FROM users WHERE user_id = ?", (p1_id,), fetch='one')
        p2_details = execute_query("SELECT ingame_name FROM users WHERE user_id = ?", (p2_id,), fetch='one')
        
        admin_message = (f"⚠️ **ম্যাচ বিরোধ!**\n\nID: `{match_id}`\n"
                         f"P1: `{p1_id}` (IGN: *{p1_details[0]}*)\n"
                         f"P2: `{p2_id}` (IGN: *{p2_details[0]}*)\n\n"
                         f"দুজনের স্ক্রিনশট নিচে দেওয়া হলো:")
        keyboard = [[InlineKeyboardButton(f"🏆 {p1_details[0]} জয়ী", callback_data=f"resolve_win_{match_id}_{p1_id}")], [InlineKeyboardButton(f"🏆 {p2_details[0]} জয়ী", callback_data=f"resolve_win_{match_id}_{p2_id}")], [InlineKeyboardButton("⛔ ম্যাচ বাতিল", callback_data=f"resolve_refund_{match_id}")]]
        
        for admin_id in ADMIN_IDS:
            await safe_send_message(context, admin_id, admin_message, parse_mode='Markdown')
            await context.bot.send_photo(admin_id, photo=dispute_screenshots[match_id]['p1_ss'], caption=f"P1 ({p1_details[0]}) এর স্ক্রিনশট")
            await context.bot.send_photo(admin_id, photo=dispute_screenshots[match_id]['p2_ss'], caption=f"P2 ({p2_details[0]}) এর স্ক্রিনশট", reply_markup=InlineKeyboardMarkup(keyboard))
        
        del dispute_screenshots[match_id]
        
    return ConversationHandler.END

async def cancel_dispute(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("বিরোধ নিষ্পত্তি বাতিল করা হয়েছে।")
    return ConversationHandler.END

# --- Commands and General Messages ---
async def result_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    match_id_tuple = execute_query("SELECT match_id FROM active_matches WHERE (player1_id = ? OR player2_id = ?) AND status IN (?, ?)", (user_id, user_id, 'in_progress', 'waiting_for_result'), fetch='one')
    
    if match_id_tuple:
        match_id = match_id_tuple[0]
        status = execute_query("SELECT status FROM active_matches WHERE match_id = ?", (match_id,), fetch='one')[0]
        if status == 'in_progress':
            await safe_send_message(context, user_id, "✅ ফলাফল জানানোর প্রক্রিয়া শুরু করা হচ্ছে...")
            for job in context.job_queue.get_jobs_by_name(f"result_{match_id}"): job.schedule_removal()
            await ask_for_result_logic(context, match_id)
        else:
            await safe_send_message(context, user_id, "ℹ️ ফলাফল জানানোর প্রক্রিয়া ইতিমধ্যে শুরু হয়েছে।")
    else:
        await safe_send_message(context, user_id, "❌ আপনার কোনো চলমান ম্যাচ নেই।")

async def main_message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user, user_id, text = update.effective_user, update.effective_user.id, update.message.text
    is_registered = execute_query("SELECT is_registered FROM users WHERE user_id = ?", (user_id,), fetch='one')[0]
    if not is_registered:
        await safe_send_message(context, user_id, "অনুগ্রহ করে প্রথমে /start লিখে রেজিস্ট্রেশন সম্পন্ন করুন।")
        return

    match_id_tuple = execute_query("SELECT match_id FROM active_matches WHERE player1_id = ? AND status = ?", (user_id, 'waiting_for_code'), fetch='one')
    if match_id_tuple:
        match_id = match_id_tuple[0]
        execute_query("UPDATE active_matches SET status = ? WHERE match_id = ?", ('in_progress', match_id))
        player2_id = execute_query("SELECT player2_id FROM active_matches WHERE match_id = ?", (match_id,), fetch='one')[0]
        escaped_code = escape_markdown(text, version=2)
        await safe_send_message(context, player2_id, text=f"🎮 ম্যাচ প্রস্তুত\!\n\n*রুম কোড:* `{escaped_code}`", parse_mode='MarkdownV2')
        await safe_send_message(context, user_id, "✅ কোড পাঠানো হয়েছে।")
        context.job_queue.run_once(trigger_ask_for_result, MATCH_DURATION_MINUTES * 60, data={'match_id': match_id}, name=f"result_{match_id}")
    else:
        # Forward to admin as deposit/withdraw request
        username_str = f"@{user.username}" if user.username else "N/A"
        admin_message = (f"👤 *ইউজার মেসেজ*\n\n*From:* {escape_markdown(user.first_name, version=2)} \({escape_markdown(username_str, version=2)}, ID: `{user.id}`\)\n\n*Message:*\n{escape_markdown(text, version=2)}")
        for admin_id in ADMIN_IDS:
            await safe_send_message(context, admin_id, text=admin_message, parse_mode='MarkdownV2')
        await safe_send_message(context, user_id, "✅ আপনার অনুরোধ অ্যাডমিনের কাছে পাঠানো হয়েছে।")

async def resolve_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = query.from_user.id
    if user_id not in ADMIN_IDS: return

    parts = query.data.split('_')
    action, match_id = parts[1], parts[2]
    match = execute_query("SELECT * FROM active_matches WHERE match_id = ?", (match_id,), fetch='one')
    if not match or match[4] != 'disputed_pending_screenshots': return

    p1_id, p2_id, fee = match[1], match[2], match[3]
    prize = (fee * 2) * (1 - PRIZE_CUT_PERCENTAGE / 100)

    if action == 'win':
        winner_id = int(parts[3])
        loser_id = p2_id if p1_id == winner_id else p1_id
        execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (prize, winner_id))
        await safe_send_message(context, winner_id, f"✅ অ্যাডমিন আপনার জয় নিশ্চিত করেছেন। পুরস্কার: `{prize:.2f} TK`।")
        await safe_send_message(context, loser_id, "❌ অ্যাডমিনের সিদ্ধান্ত অনুযায়ী আপনি হেরেছেন।")
    elif action == 'refund':
        execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (fee, p1_id))
        execute_query("UPDATE users SET balance = balance + ? WHERE user_id = ?", (fee, p2_id))
        await safe_send_message(context, p1_id, "⛔ ম্যাচটি বাতিল করা হয়েছে। আপনার ফি ফেরত দেওয়া হয়েছে।")
        await safe_send_message(context, p2_id, "⛔ ম্যাচটি বাতিল করা হয়েছে। আপনার ফি ফেরত দেওয়া হয়েছে।")
    
    await query.edit_message_text(f"✅ সিদ্ধান্ত কার্যকর করা হয়েছে।")
    execute_query("DELETE FROM active_matches WHERE match_id = ?", (match_id,))