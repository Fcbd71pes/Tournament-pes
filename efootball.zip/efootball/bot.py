# bot.py
import logging
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    CallbackQueryHandler, ConversationHandler
)

import database
from config import BOT_TOKEN, GET_IGN, GET_EMAIL, GET_PHONE, DISPUTE_SCREENSHOT
from handlers import registration, wallet, matchmaking, admin

# Logging setup
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    # Setup database first
    database.setup_database()

    # Create the Application
    application = Application.builder().token(BOT_TOKEN).build()

    # --- Conversation Handlers for multi-step processes ---
    reg_conv = ConversationHandler(
        entry_points=[CommandHandler("start", registration.start)],
        states={
            GET_IGN: [MessageHandler(filters.TEXT & ~filters.COMMAND, registration.get_ign)],
            GET_EMAIL: [MessageHandler(filters.TEXT & ~filters.COMMAND, registration.get_email),
                        CallbackQueryHandler(registration.skip_email, pattern='^skip_email$')],
            GET_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, registration.get_phone)],
        },
        fallbacks=[CommandHandler("cancel", registration.cancel_registration)],
        per_message=False,
        map_to_parent={
            ConversationHandler.END: ConversationHandler.END
        }
    )
    
    dispute_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(matchmaking.process_match_end, pattern='^result_')],
        states={
            DISPUTE_SCREENSHOT: [MessageHandler(filters.PHOTO, matchmaking.screenshot_handler)]
        },
        fallbacks=[CommandHandler("cancel", matchmaking.cancel_dispute)],
        conversation_timeout=600, # 10 minutes for users to submit screenshots
        map_to_parent={
            ConversationHandler.END: ConversationHandler.END
        }
    )
    
    # --- Main Callback Query Handler to route button clicks ---
    async def main_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
        is_registered = database.execute_query("SELECT is_registered FROM users WHERE user_id = ?", (update.callback_query.from_user.id,), fetch='one')[0]
        if not is_registered:
            await update.callback_query.answer("অনুগ্রহ করে প্রথমে /start লিখে রেজিস্ট্রেশন সম্পন্ন করুন।", show_alert=True)
            return

        query = update.callback_query
        data = query.data
        await query.answer()

        if data == 'play_1v1': await matchmaking.play_1v1(update, context)
        elif data.startswith('fee_'): await matchmaking.fee_handler(update, context)
        elif data == 'my_wallet': await wallet.my_wallet(update, context)
        elif data == 'deposit': await wallet.deposit_request(update, context)
        elif data == 'withdraw': await wallet.withdraw_request(update, context)
        elif data == 'my_referrals': await wallet.my_referrals(update, context)
        elif data.startswith('resolve_'): await matchmaking.resolve_handler(update, context)
        # Note: result_ callbacks are handled by the dispute_conv entry point

    # --- Add Handlers to the Application ---
    application.add_handler(reg_conv)
    application.add_handler(dispute_conv)
    
    # Admin commands
    application.add_handler(CommandHandler("add_balance", admin.add_balance))

    # User commands
    application.add_handler(CommandHandler("start", registration.start)) # Also a fallback for reg_conv
    application.add_handler(CommandHandler("result", matchmaking.result_command))
    
    # Main button handler
    application.add_handler(CallbackQueryHandler(main_callback_handler, pattern=r'^(?!result_).+'))

    # Message Handler (for room codes and deposit info)
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, matchmaking.main_message_handler))
    
    logger.info("Bot is starting up with professional modular architecture...")
    application.run_polling()

if __name__ == '__main__':
    main()