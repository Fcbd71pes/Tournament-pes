# database.py
import sqlite3
import time
from config import DB_NAME

def get_connection():
    return sqlite3.connect(DB_NAME, check_same_thread=False)

def setup_database():
    conn = get_connection()
    cursor = conn.cursor()
    # Create users table with referral columns
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY, username TEXT, balance REAL DEFAULT 0.0,
            ingame_name TEXT, email TEXT, phone_number TEXT, is_registered INTEGER DEFAULT 0,
            referred_by INTEGER, first_deposit_done INTEGER DEFAULT 0
        )''')
    # Create matchmaking queue table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS matchmaking_queue (
            user_id INTEGER PRIMARY KEY, fee REAL, timestamp INTEGER
        )''')
    # Create active matches table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS active_matches (
            match_id TEXT PRIMARY KEY, player1_id INTEGER, player2_id INTEGER,
            fee REAL, status TEXT, p1_result TEXT, p2_result TEXT
        )''')
    conn.commit()
    conn.close()

def execute_query(query, params=(), fetch=None):
    """A generic function to execute database queries."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    
    if fetch == 'one':
        result = cursor.fetchone()
    elif fetch == 'all':
        result = cursor.fetchall()
    else:
        result = None
        
    conn.commit()
    conn.close()
    return result

# You can add more specific functions here if needed, e.g.:
# def get_user_balance(user_id):
#     return execute_query("SELECT balance FROM users WHERE user_id = ?", (user_id,), fetch='one')[0]